
 /*==================================================================
    [ Change user type ]*/
	var userType = 1;
function changeUser(){
	 
	 if(userType==0){
		document.getElementById("lblType").innerHTML="User Login";
		document.getElementById("lblLink").innerHTML="For Admin login";
		document.getElementById("txtADid").value="";
		document.getElementById("txtADid").readOnly = false;
		document.getElementById("txtADid").focus();
		
		document.getElementById("txtPass").value="";
		userType=1;
	 }
	 
	 else{
		document.getElementById("lblType").innerHTML="Admin Login";
		document.getElementById("lblLink").innerHTML="For User login";
		document.getElementById("txtADid").value="admin";
		document.getElementById("txtPass").value="";
		document.getElementById("txtADid").focus();
		document.getElementById("txtADid").readOnly = true;
		userType=0;
	 }
}

/*==================================================================*/

(function ($) {
    "use strict";


    /*==================================================================
    [ Focus input ]*/
    $('.input100').each(function(){
        $(this).on('blur', function(){
            if($(this).val().trim() != "") {
                $(this).addClass('has-val');
            }
            else {
                $(this).removeClass('has-val');
            }
        })    
    })
  
  
    /*==================================================================
    [ Validate ]*/
    var input = $('.validate-input .input100');

    $('.validate-form').on('submit',function(){
        var check = true;

        for(var i=0; i<input.length; i++) {
            if(validate(input[i]) == false){
                showValidate(input[i]);
                check=false;
            }
        }

        return check;
    });


    $('.validate-form .input100').each(function(){
        $(this).focus(function(){
           hideValidate(this);
        });
    });

    function validate (input) {
     
            if($(input).val().trim() == ''){
                return false;
            }
        
    }

    function showValidate(input) {
        var thisAlert = $(input).parent();

        $(thisAlert).addClass('alert-validate');
    }

    function hideValidate(input) {
        var thisAlert = $(input).parent();

        $(thisAlert).removeClass('alert-validate');
    }
    
    /*==================================================================
    [ Show pass ]*/
    


})(jQuery);